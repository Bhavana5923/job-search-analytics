"""
Run the full job-search-analytics pipeline: Phase 1 (personal tracker)
followed by Phase 2 (live API pull analysis).
"""
import phase1_tracker_analysis as phase1
import phase2_live_analysis as phase2

if __name__ == '__main__':
    print("#" * 60)
    print("PHASE 1: Personal Job Tracker Analysis (50 listings)")
    print("#" * 60)
    phase1.run()

    print("\n" + "#" * 60)
    print("PHASE 2: Live Job Listings Analysis (Indeed API)")
    print("#" * 60)
    phase2.run()

    print("\nAll done. Charts saved in /charts.")
