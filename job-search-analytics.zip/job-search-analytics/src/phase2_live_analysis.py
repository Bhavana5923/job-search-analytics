"""
Phase 2: Live Job Listings Analysis
Extends Phase 1 by analyzing live job listings pulled in real-time from
the Indeed Jobs API, demonstrating the pipeline working on fresh,
unseen data rather than only the static manually-tracked dataset.

Note: live data was pulled via an external job-search tool and saved to
data/live_pull_bengaluru.csv. This script analyzes that snapshot. To
refresh it, pull a new batch of listings and overwrite the CSV.
"""
import pandas as pd
import matplotlib.pyplot as plt
import re
import os

DATA_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'live_pull_bengaluru.csv')
CHARTS_DIR = os.path.join(os.path.dirname(__file__), '..', 'charts')

SKILL_KEYWORDS = ['Python', 'SQL', 'Power BI', 'PowerBI', 'Tableau', 'Excel', 'BI', 'Analytics', 'AI']


def load_data():
    return pd.read_csv(DATA_PATH)


def extract_skills(title):
    found = []
    for s in SKILL_KEYWORDS:
        if re.search(s, title, re.IGNORECASE):
            found.append(s.replace('PowerBI', 'Power BI'))
    return found


def analyze(df):
    df['skills_found'] = df['job_title'].apply(extract_skills)
    all_skills = [s for row in df['skills_found'] for s in row]
    skill_counts = pd.Series(all_skills).value_counts()

    type_counts = df['job_type'].value_counts()
    company_counts = df['company'].value_counts()

    return {
        'skill_counts': skill_counts,
        'type_counts': type_counts,
        'company_counts': company_counts,
    }


def make_charts(results):
    os.makedirs(CHARTS_DIR, exist_ok=True)

    plt.figure(figsize=(8, 5))
    results['skill_counts'].plot(kind='bar', color='#4C72B0')
    plt.title('Skill Mentions in Live Job Titles (Indeed, Bengaluru)')
    plt.ylabel('Number of Postings')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.savefig(os.path.join(CHARTS_DIR, 'p2_live_skills.png'), dpi=150)
    plt.close()

    plt.figure(figsize=(6, 6))
    results['type_counts'].plot(kind='pie', autopct='%1.0f%%', startangle=90)
    plt.title('Live Postings: Job Type Distribution')
    plt.ylabel('')
    plt.tight_layout()
    plt.savefig(os.path.join(CHARTS_DIR, 'p2_live_jobtype.png'), dpi=150)
    plt.close()

    plt.figure(figsize=(8, 5))
    results['company_counts'].plot(kind='barh', color='#55A868')
    plt.title('Live Postings by Company')
    plt.xlabel('Number of Postings')
    plt.tight_layout()
    plt.savefig(os.path.join(CHARTS_DIR, 'p2_live_companies.png'), dpi=150)
    plt.close()


def run():
    df = load_data()
    results = analyze(df)
    for key, val in results.items():
        print(f"\n=== {key} ===")
        print(val)
    make_charts(results)
    print("\nPhase 2 charts saved to /charts")
    return results


if __name__ == '__main__':
    run()
