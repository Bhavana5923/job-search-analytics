"""
Phase 1: Personal Job Search Tracker Analysis
Analyzes 50 manually-tracked job listings across Internshala, Naukri,
LinkedIn, and Indeed to surface skill demand, platform performance,
and location-based fit trends.
"""
import pandas as pd
import matplotlib.pyplot as plt
import os

DATA_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'Job_Tracker_50_Rows.xlsx')
CHARTS_DIR = os.path.join(os.path.dirname(__file__), '..', 'charts')


def load_data():
    return pd.read_excel(DATA_PATH)


def analyze(df):
    df['skills_list'] = df['Skills'].apply(lambda x: [s.strip() for s in x.split(',')])
    all_skills = [s for row in df['skills_list'] for s in row]
    skill_counts = pd.Series(all_skills).value_counts()

    platform_counts = df['Platform'].value_counts()
    avg_fit_by_platform = df.groupby('Platform')['Fit Score'].mean().sort_values(ascending=False)

    location_counts = df['Location'].value_counts()
    avg_fit_by_location = df.groupby('Location')['Fit Score'].mean().sort_values(ascending=False)

    fit_tiers = pd.cut(df['Fit Score'], bins=[0, 80, 90, 100],
                        labels=['Low (<=80)', 'Medium (81-90)', 'High (91-100)'])
    fit_tier_counts = fit_tiers.value_counts()

    role_counts = df['Job Title'].value_counts()

    return {
        'skill_counts': skill_counts,
        'platform_counts': platform_counts,
        'avg_fit_by_platform': avg_fit_by_platform,
        'location_counts': location_counts,
        'avg_fit_by_location': avg_fit_by_location,
        'fit_tier_counts': fit_tier_counts,
        'role_counts': role_counts,
    }


def make_charts(results):
    os.makedirs(CHARTS_DIR, exist_ok=True)

    plt.figure(figsize=(9, 5))
    results['skill_counts'].head(10).plot(kind='bar', color='#4C72B0')
    plt.title('Top 10 In-Demand Skills (Personal Tracker, 50 Listings)')
    plt.ylabel('Number of Listings')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.savefig(os.path.join(CHARTS_DIR, 'p1_top_skills.png'), dpi=150)
    plt.close()

    plt.figure(figsize=(6, 6))
    results['platform_counts'].plot(kind='pie', autopct='%1.0f%%', startangle=90)
    plt.title('Listings by Platform')
    plt.ylabel('')
    plt.tight_layout()
    plt.savefig(os.path.join(CHARTS_DIR, 'p1_platform_distribution.png'), dpi=150)
    plt.close()

    plt.figure(figsize=(7, 5))
    results['avg_fit_by_platform'].plot(kind='bar', color='#55A868')
    plt.title('Average Fit Score by Platform')
    plt.ylabel('Avg Fit Score')
    plt.ylim(70, 100)
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(os.path.join(CHARTS_DIR, 'p1_fitscore_by_platform.png'), dpi=150)
    plt.close()

    plt.figure(figsize=(7, 5))
    results['location_counts'].plot(kind='bar', color='#C44E52')
    plt.title('Listings by Location')
    plt.ylabel('Number of Listings')
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(os.path.join(CHARTS_DIR, 'p1_location_distribution.png'), dpi=150)
    plt.close()

    plt.figure(figsize=(6, 6))
    results['fit_tier_counts'].plot(kind='pie', autopct='%1.0f%%', startangle=90,
                                     colors=['#C44E52', '#DD8452', '#55A868'])
    plt.title('Fit Score Tier Distribution')
    plt.ylabel('')
    plt.tight_layout()
    plt.savefig(os.path.join(CHARTS_DIR, 'p1_fit_tiers.png'), dpi=150)
    plt.close()

    plt.figure(figsize=(8, 5))
    results['role_counts'].plot(kind='barh', color='#8172B2')
    plt.title('Listings by Role Type')
    plt.xlabel('Number of Listings')
    plt.tight_layout()
    plt.savefig(os.path.join(CHARTS_DIR, 'p1_role_types.png'), dpi=150)
    plt.close()


def run():
    df = load_data()
    results = analyze(df)
    for key, val in results.items():
        print(f"\n=== {key} ===")
        print(val)
    make_charts(results)
    print("\nPhase 1 charts saved to /charts")
    return results


if __name__ == '__main__':
    run()
