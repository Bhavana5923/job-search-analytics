# Job Search Analytics: From Personal Tracker to Live Pipeline

## Overview
A two-phase data analytics project built during an active fresher job search. It analyzes job market data to surface in-demand skills, best-performing platforms, and location trends — first on a manually curated dataset, then extended to pull and analyze live job listings via the Indeed Jobs API.

This project demonstrates the full data analytics workflow: **ingestion → cleaning → transformation → analysis → visualization → actionable insight** — applied twice, on two different data sources, with a shared analytical approach.

## Project Structure
```
job-search-analytics/
├── data/
│   ├── Job_Tracker_50_Rows.xlsx       # Phase 1: manually tracked listings
│   └── live_pull_bengaluru.csv        # Phase 2: live API pull snapshot
├── src/
│   ├── phase1_tracker_analysis.py     # Analysis of personal tracker
│   ├── phase2_live_analysis.py        # Analysis of live API data
│   └── main.py                        # Runs both phases end-to-end
├── charts/                            # All generated visualizations
├── requirements.txt
└── README.md
```

## Phase 1: Personal Job Tracker Analysis
**Source:** 50 listings manually tracked across Internshala, Naukri, LinkedIn, and Indeed, scored for fit (0–100) against my own skill set.

**Key Insights:**
- **SQL and Excel are the most in-demand skills**, each appearing in 60% of listings (30/50) — non-negotiable for entry-level data roles.
- **Power BI and Python** follow at 30% each (15/50).
- **LinkedIn** yields both the highest volume of relevant listings (13) and the highest average fit score (88.2) — the strongest platform for this search.
- **Internshala and Naukri** show lower average fit scores (~83), suggesting these need more filtering before applying.
- **Chennai-based roles** scored highest on average fit (87.1) among five tracked locations.
- Only **18%** of listings (9/50) scored in the "High fit" tier (91-100) — most cluster in the medium range.

**Charts:** `p1_top_skills.png`, `p1_platform_distribution.png`, `p1_fitscore_by_platform.png`, `p1_location_distribution.png`, `p1_fit_tiers.png`, `p1_role_types.png`

## Phase 2: Live API Pipeline
**Source:** Live job listings pulled in real-time from the Indeed Jobs API for "Data Analyst" roles in Bengaluru — extends Phase 1's static analysis into a pipeline that works on fresh, unseen data.

**Key Insights:**
- Analytics/BI and SQL keywords dominate live Data Analyst job titles, consistent with Phase 1 findings.
- Full-time roles make up the majority of live postings, with some part-time and permanent listings mixed in.
- Listing volume per company is mostly 1, with occasional employers (e.g. Empower) posting multiple openings — useful signal for which companies are actively scaling data teams.

**Charts:** `p2_live_skills.png`, `p2_live_jobtype.png`, `p2_live_companies.png`

## How to Run
```bash
pip install -r requirements.txt
cd src
python main.py
```
This runs both phases sequentially and regenerates all charts in `/charts`.

To refresh Phase 2 with new live data, pull a fresh batch of listings and overwrite `data/live_pull_bengaluru.csv`, then re-run `phase2_live_analysis.py`.

## Tech Stack
Python, Pandas, Matplotlib, openpyxl, regex, Indeed Jobs API

## Next Steps / Extensions
- Automate Phase 2 ingestion on a schedule (cron) to track listing trends over time
- Move storage from Excel/CSV to a SQL database for historical trend queries
- Pull full job *descriptions* (not just titles) for richer skill extraction in Phase 2
- Add a simple ML classifier (logistic regression) to predict fit score from listing features
- Layer an interactive Power BI/Tableau dashboard on top of the combined dataset

## Why This Project
Built from a real, active job search rather than a static Kaggle dataset. Phase 1 shows analytical rigor on curated data; Phase 2 shows the ability to extend that analysis into a live, automatable pipeline — directly mapping to the Data Analytics, Data Science, and Data Engineering tracks of an entry-level data role.
